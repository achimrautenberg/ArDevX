#include "Person.h"

int main() {
	Person person1;
	person1.setMale(false);
	person1.setAge(12);

	Person person2;
	person2.setAge(11);

	return 0;
}
