#include "Person.h"

Person::Person() {
	m_iAge = 0;
	m_bMale = true; //false
}

void Person::setAge(int iAge) {
	m_iAge = iAge;
}

int Person::age() {
	return m_iAge;
}

void Person::setMale(bool bMale) {
	m_bMale = bMale;
}
