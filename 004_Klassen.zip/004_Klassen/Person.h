#ifndef PERSON_H
#define PERSON_H

class Person {

private:
	int m_iAge;
	bool m_bMale;

public:
	Person();
	void setAge(int iAge);
	int age();
	void setMale(bool bMale);

};


#endif // PERSON_H
