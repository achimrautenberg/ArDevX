#pragma once

#include "db_global.h"
#include <string>
#include <QSqlDatabase>
#include <QJsonObject>

/**
 * Deklaration einer extern freigegeben Funktion.
 * Diese Funktion dient als Nachrichtensystem von
 * dem Server hin zur DLL.
 * Jede DLL muss diese Funktion bereit stellen,
 * damit der Server die Funktion läd.
 * @date 2021-04-24
 * @author Achim Rautenberg
 */
extern "C" DB_EXPORT int msgToLib(std::string & s);

/**
 * Mit dieser Funktion werden alle grundlegenden Objekte in dieser DLL initialisiert.
 * Dadurch kann die Dll optimal genutzt werden, wenn der der Server sie für eine Nachricht
 * verwenden möchte
 * @date 2021-04-25
 * @author Achim Rautenberg
 */
QJsonObject initLib();



/**
 * Räumt unsere Bilbliothek auf und gibt den allozierten Speicher wieder frei.
 * @date 2021-04-25
 * @author Achim Rautenberg
 */
QJsonObject cleanUpLib();

class Db {
private:
	/**
	 * Das Verbindungsobjekt zur Kommunikation mit der Sqlite Datenbank
	 * @date 2021-04-25
	 * @author Achim Rautenberg
	 *
	 */
	QSqlDatabase m_db;

public:
	/**
	 * Konstruktor
	 * @date 2021-04-25
	 * @author Achim Rautenberg
	 */
	Db();

	/**
	  Destruktor
	  @date 2021-04-25
	  @author Achim Rautenberg
	  */
	~Db();

	/**
	 * Läd die Datenbankdatei. Gegebenenfalls wird diese dabei erstellt.
	 *
	 * @param Der Pfand inklusive Dateiname von der Datenbank, die zu öffnen ist.
	 * @date 2021-04-25
	 * @author Achim Rautenberg
	 */
	void loadDb(const QString & sFilename);

	/**
	 * Breitet die Datenbankstruktur vor.
	 * Hier werden also die Tabellen sowie deren Spalten definiert.
	 * @date 2021-04-25
	 * @author Achim Rautenberg
	 * @date 2021-04-25
	 */
	void prepareDb();
};
