#include "Db.h"
#include <QDebug>
#include <QString>
#include <QJsonObject>
#include <QJsonDocument>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QCoreApplication>

Db * m_pDb = nullptr;

QJsonObject initLib() {
	qDebug() << "initLib" << m_pDb;
	if(!m_pDb) {
		m_pDb = new Db();
	}
	QJsonObject o;
	return o;
}

QJsonObject cleanUpLib() {
	qDebug() << "cleaning up this library";
	if(m_pDb) {
		delete m_pDb;
		m_pDb = nullptr;
	}
	QJsonObject o;
	return o;
}


extern "C" DB_EXPORT int msgToLib(std::string & s) {
	qDebug() << "incomming message" << QString::fromStdString(s);
	QString sTmp = QString::fromStdString(s);
	QJsonDocument doc = QJsonDocument::fromJson(sTmp.toUtf8());
	QJsonObject jsMsgIn = doc.object();
	QJsonObject jsMsgOut;
	QString sCmd = jsMsgIn.value("cmd").toString().toLower();
	bool bKnown = false;

	if(sCmd == "initlib") {
		jsMsgOut = initLib();
		bKnown = true;
	}
	if(sCmd == "cleanuplib") {
		jsMsgOut = cleanUpLib();
		bKnown = true;
	}

	if(!bKnown) {
		return 0;
	}


	doc.setObject(jsMsgOut);
	sTmp = doc.toJson();
	s = sTmp.toStdString();
	return 1;
}

Db::Db() {
	QString sFilenameDb = qApp->applicationDirPath() + "/tiny.db";
	qDebug() << "Db filename:" << sFilenameDb;
	loadDb(sFilenameDb);
}

Db::~Db() {

}

void Db::loadDb(const QString & sFilename) {
	m_db = QSqlDatabase::addDatabase("QSQLITE" , "TinyDb");
	m_db.setDatabaseName(sFilename);
	bool bOpen = m_db.open();
	qDebug() << "Database is open: " << bOpen;
	if(bOpen) prepareDb();
}

void Db::prepareDb() {
	QSqlQuery q(m_db);
	q.prepare("CREATE TABLE IF NOT EXISTS accounts(username TEXT, password TEXT)");
	if(!q.exec()) {
		qDebug() << q.lastError().text();
	}
}
