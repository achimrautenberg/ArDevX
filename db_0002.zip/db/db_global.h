#pragma once

#include <QtCore/qglobal.h>


#if defined(DB_LIBRARY)
#  define DB_EXPORT Q_DECL_EXPORT
#else
#  define DB_EXPORT Q_DECL_IMPORT
#endif
