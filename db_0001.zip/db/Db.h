#pragma once

#include "db_global.h"
#include <string>

/**
 * Deklaration einer extern freigegeben Funktion.
 * Diese Funktion dient als Nachrichtensystem von
 * dem Server hin zur DLL.
 * Jede DLL muss diese Funktion bereit stellen,
 * damit der Server die Funktion läd.
 * @date 2021-04-24
 * @author Achim Rautenberg
 */
extern "C" DB_EXPORT int msgToLib(std::string & s);
