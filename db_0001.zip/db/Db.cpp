#include "Db.h"
#include <QDebug>
#include <QString>
#include <QJsonObject>
#include <QJsonDocument>

extern "C" DB_EXPORT int msgToLib(std::string & s) {
	QString sTmp = QString::fromStdString(s);
	QJsonDocument doc = QJsonDocument::fromJson(sTmp.toUtf8());
	QJsonObject jsMsgIn = doc.object();

	//TODO Nachricht verarbeiten
	//TODO Wenn Nachricht nicht bekannt, dann return 0
	//TODO Wenn Nachricht bekannt, aber Fehler dann return 2

	QJsonObject jsMsgOut; //<<<--- Ergebnis von Nachricht verarbeiten
	jsMsgOut.insert("demo" , "Hello World from DLL");
	jsMsgOut.insert("your Input" , jsMsgIn);
	doc.setObject(jsMsgOut);
	sTmp = doc.toJson();
	s = sTmp.toStdString();
	return 1;
}
