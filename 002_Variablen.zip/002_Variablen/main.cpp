int main() {
	int iGanzeZahl;
	iGanzeZahl = 1;

	int iZweiteZahl = 2;
	iGanzeZahl = iZweiteZahl;

	iGanzeZahl = (3 + 2) * iGanzeZahl / 2;

	int iDritteZahl = 2.9;

	char cInitial = 'A';
	cInitial = 'B';
	cInitial = 'A' + 'B';
	cInitial = 'A' + 3;

	float fZahl = 1.2;
	double dZahl = 1.2;

	dZahl = iGanzeZahl;
	iGanzeZahl = dZahl;


	return 0;
}
