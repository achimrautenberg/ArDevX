#include "common.h"
#include <QCoreApplication>

Account Common::m_account;


void Common::setAccount(const Account & acc) {
	m_account = acc;
}

Account & Common::account() {
	return m_account;
}

QList<Account> Common::loadAccounts() {
	QString sFilename = qApp->applicationDirPath() + "/accounts.json";
	return Account::fromJsonFile(sFilename);
}
