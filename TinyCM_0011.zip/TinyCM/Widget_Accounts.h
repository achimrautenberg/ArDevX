#ifndef WIDGET_ACCOUNTS_H
#define WIDGET_ACCOUNTS_H

/**
 * Das Widget Accounts stellt eine Maske bereit mit der wir
 * Accounts, die sich am Tiny CM anmelden dürfen editieren können.
 * @date 2021-04-11
 * @author Achim Rautenberg
 */

#include <QWidget>
#include "Account.h"

/**
 * Das gezeichnete UI Objekt
 * @date 2021-04-11
 * @author Achim Rautenberg
 */
namespace Ui {
	class Widget_Accounts;
}

class Widget_Accounts : public QWidget
{
	Q_OBJECT

private:
	Ui::Widget_Accounts *ui;


public:
	/**
	 * Ein einfacher Konstruktor
	 * @date 2021-04-11
	 * @author Achim Rautenberg
	 */
	explicit Widget_Accounts(QWidget *parent = nullptr);

	/**
	 * Ein einfacher Destruktor
	 * Wir legen ein Actions Menu auf den Toolbutton.
	 * Wir hatten versucht dieses Menu hier zu löschen, was einen Absturz verursachte.
	 * @date 2021-04-11
	 * @author Achim Rautenberg
	 */
	~Widget_Accounts();

	/**
	  Wird über den Konstruktor aufgerufen.
	  Hier wird ein Menü erstellt, welches auf den Menü Knopf in der UI
	  gelegt wird. Dieses Menü erlaubt uns die allgemeinen Steuerungen
	  in dieser Maske.
	  @date 2021-04-11
	  @author Achim Rautenberg
	 */
	void initMenuButton();

	/**
	 * Wird vom Konstruktor aus aufgerufen.
	 * Diese Funktion listet unsere Accounts im List-Widget auf.
	 * @date 2021-04-11
	 * @author Achim Rautenberg
	 */
	void listAccounts();

	/**
	 * Diese Funktion bekommt einen Account übergeben
	 * und fügt diesen als Objekt in unser List Widget ein
	 * @date 2021-04-11
	 * @author Achim Rautenberg
	 */
	void addAccountToList(const Account & account);

private slots:
	/**
	  Dieser Slot wird über das Menü aufgerufen.
	  Er schaltet unser Widget um in den Bereich Plugins

	  TODO! Das haben wir nur zu Testzwecken gemacht. In Wirklichkeit
	  wollen wir auf einen Home Bereich zurück.

	  @date 2021-04-11
	  @author Achim Rautenberg
	*/
	void onActionSwitchToPlugins();

	/**
	 * Mit diesem Action, welches über das Menü aufgerufen wird,
	 * wollen wir einen neuen Accounts abspeichern
	 * @date 2021-04-11
	 * @author Achim Rautenberg
	 */
	void onActionAddAccount();

	/**
	 * Wird über das Menü aufgerufen.
	 * Soll einen existierenden Account löschen.
	 * @date 2021-04-11
	 * @author Achim Rautenberg
	 */
	void onActionDeleteAccount();

};

#endif // WIDGET_ACCOUNTS_H
