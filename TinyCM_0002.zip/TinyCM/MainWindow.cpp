#include "MainWindow.h"
#include "ui_MainWindow.h"
#include "Dlg_Login.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
	m_pUi = new Ui::MainWindow();
	m_pUi->setupUi(this);
}

MainWindow::~MainWindow()
{
	delete m_pUi;
}

void MainWindow::showEvent(QShowEvent *event) {
	QMainWindow::showEvent(event);
	QMetaObject::invokeMethod(this , "onShown" , Qt::ConnectionType::QueuedConnection);

}

void MainWindow::onShown() {
	Dlg_Login dlgLogin(this);
	int iRet = dlgLogin.exec();
}
