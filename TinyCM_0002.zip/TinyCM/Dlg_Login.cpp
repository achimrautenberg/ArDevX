#include "Dlg_Login.h"
#include "ui_Dlg_Login.h"
#include <QMessageBox>

Dlg_Login::Dlg_Login(QWidget *parent) : QDialog(parent) {
	ui = new Ui::Dlg_Login();
	ui->setupUi(this);

	connect(ui->btnLogin , SIGNAL(clicked()) , this , SLOT(onBtnLogin()));
}

Dlg_Login::~Dlg_Login()
{
	delete ui;
}

void Dlg_Login::onBtnLogin() {
	QString sUsername = ui->txtUsername->text();
	QString sPassword = ui->txtPassword->text();

	if(sUsername.count() > 0) {
		if(sPassword.count() >= 5) {
			accept();
		} else {
			QMessageBox::critical(this , "Error" , "The password is too short");
		}
	} else {
		QMessageBox::critical(this , "Error" , "The username may not be empty");
	}
}
