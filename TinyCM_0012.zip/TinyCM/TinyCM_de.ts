<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>Dlg_Login</name>
    <message>
        <location filename="Dlg_Login.ui" line="14"/>
        <source>TinyCM - Login</source>
        <translation>TinyCM - Login</translation>
    </message>
    <message>
        <location filename="Dlg_Login.ui" line="35"/>
        <source>Username</source>
        <translation>Benutzer</translation>
    </message>
    <message>
        <location filename="Dlg_Login.ui" line="45"/>
        <source>Password</source>
        <translation>Passwort</translation>
    </message>
    <message>
        <location filename="Dlg_Login.ui" line="89"/>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <location filename="Dlg_Login.cpp" line="50"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="Dlg_Login.cpp" line="50"/>
        <source>Login failed</source>
        <translation>Login fehlgeschlagen</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="MainWindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>TinyCM</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>username</source>
        <translation type="vanished">Benutzer</translation>
    </message>
</context>
<context>
    <name>Widget_Accounts</name>
    <message>
        <location filename="Widget_Accounts.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Widget_Accounts.ui" line="20"/>
        <source>Accounts -&gt; Plugins</source>
        <translation>Accounts -&gt; Plugins</translation>
    </message>
</context>
<context>
    <name>Widget_Plugins</name>
    <message>
        <location filename="Widget_Plugins.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Widget_Plugins.ui" line="20"/>
        <source>Plugins -&gt; Accounts</source>
        <translation>Plugins -&gt; Accounts</translation>
    </message>
</context>
</TS>
