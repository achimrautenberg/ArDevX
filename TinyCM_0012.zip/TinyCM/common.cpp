#include "common.h"
#include <QCoreApplication>

Account Common::m_account;
QString Common::m_sFilenameAccounts;

Common::Common() {
	m_sFilenameAccounts = qApp->applicationDirPath() + "/accounts.json";
}

void Common::setAccount(const Account & acc) {
	m_account = acc;
}

Account & Common::account() {
	return m_account;
}

QList<Account> Common::loadAccounts() {
	return Account::fromJsonFile(m_sFilenameAccounts);
}

void Common::saveAccounts(const QList<Account> & accounts) {
	Account::toJsonFile(accounts , m_sFilenameAccounts);
}
