#pragma once

/*
 * Ein Websocket Server, der Verbidungen über das Websocket Protokoll annimmt.
 * @date 2021-04-14
 * @author Achim Rautenberg
*/

#include <QObject>
#include <QWebSocketServer>
#include <QWebSocket>



class WebsocketServer : public QObject {
	Q_OBJECT

private:
	/*
	 * Das eigentliche Serverobjekt
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	QWebSocketServer * m_pServer;

public:
	/*
	 * Der Konstruktor
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	WebsocketServer();

	/*
	 * Der Destruktor
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	~WebsocketServer();

	/*
	 * Mit dieser Funktion wird der Server gestartet. Er horcht dann auf allen Netzwerkdevices auf
	 * dem übergebenen Port
	 * @param iPort Der Port auf dem der Server horchen soll.
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	void startServer(const int & iPort);

private slots:
	/*
	 * Dieser Slot wird aufgerufen, wenn ein neuer Client sich mit dem Server verbindet
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	void onNewConnection();

	/*
	 * Dieser Slot wird aufgerufen, wenn der Client dem Server eine Nachricht schickt.
	 * Die Nachricht ist als QByteArray (UTF8 Codierung) übergeben.
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	void onBinaryMessageReceived(const QByteArray & message);

	/*
	 * Dieser Slot wird aufgerufen, wenn der Client dem Server eine Nachricht schickt.
	 * Die Nachricht ist als QString übergeben. Der Server geht davon aus, dass der
	 * QString einem UTF8 codierten QByteArray entspricht.
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	void onTextMessageReceived(const QString &message);
};

