#include "MainWindow.h"
#include "ui_MainWindow.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
	m_pUi = new Ui::MainWindow();
	m_pUi->setupUi(this);
	m_pUi->lineEdit->setText("Hallo");
}

MainWindow::~MainWindow()
{
	delete m_pUi;
}

