#include "WebsocketClient.h"
#include <QUrl>
#include <QDebug>
#include <QJsonDocument>

WebsocketClient::WebsocketClient(QObject *parent) : QObject(parent) {
	m_pClient = new QWebSocket();
	connect(m_pClient , SIGNAL(connected()) , this , SLOT(onConnected()));
	connect(m_pClient , SIGNAL(textMessageReceived(const QString &)) , this , SLOT(onTextMessageReceived(const QString &)));
	connect(m_pClient , SIGNAL(binaryMessageReceived(const QByteArray &)) , this , SLOT(onBinaryMessageReceived(const QByteArray &)));
}

WebsocketClient::~WebsocketClient() {
	m_pClient->deleteLater();
}

void WebsocketClient::connectToServer(const QString & sUrl) {
	m_pClient->open(QUrl(sUrl));
}

void WebsocketClient::sendMessage(const QJsonObject & o) {
	QJsonDocument doc;
	doc.setObject(o);
	m_pClient->sendBinaryMessage(doc.toJson());
}

void WebsocketClient::onConnected() {
	qDebug() << "I am connected!";

	QJsonObject oMsg;
	oMsg.insert("txt" , "Hello TinyServ");
	sendMessage(oMsg);
}

void WebsocketClient::onTextMessageReceived(const QString & message) {
	onBinaryMessageReceived(message.toUtf8());
}

void WebsocketClient::onBinaryMessageReceived(const QByteArray & message) {
	qDebug() << message;
}
