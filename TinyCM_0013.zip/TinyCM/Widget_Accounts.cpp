#include "Widget_Accounts.h"
#include "ui_Widget_Accounts.h"
#include "MainWindow.h"
#include <QMenu>
#include <QDebug>


Widget_Accounts::Widget_Accounts(QWidget *parent) : QWidget(parent) {
	ui = new Ui::Widget_Accounts();
	ui->setupUi(this);
	initMenuButton();
	listAccounts();
	connect(ui->btnAddAccount , SIGNAL(clicked()) , this , SLOT(onActionAddAccount()));
}

Widget_Accounts::~Widget_Accounts() {
	delete ui;
}

void Widget_Accounts::initMenuButton() {
	QMenu * pMenu = new QMenu();
	ui->btnMenu->setMenu(pMenu);

	QAction * pActionSwitchToPlugins = pMenu->addAction(tr("--> Plugins"));
	connect(pActionSwitchToPlugins , SIGNAL(triggered()) , this , SLOT(onActionSwitchToPlugins()));

	QAction * pActionAddAccount = pMenu->addAction(tr("Add Account"));
	connect(pActionAddAccount , SIGNAL(triggered()) , this , SLOT(onActionAddAccount()));

	QAction * pActionDeleteAccount = pMenu->addAction(tr("Delete Account"));
	connect(pActionDeleteAccount , SIGNAL(triggered()) , this , SLOT(onActionDeleteAccount()));
}

void Widget_Accounts::listAccounts() {
	QList<Account> accounts = Common::loadAccounts();
	for(int i = 0 ; i < accounts.count() ; i++) {
		Account account = accounts[i];
		addAccountToList(account);
	}
}

void Widget_Accounts::addAccountToList(const Account & account) {
	QListWidgetItem * pItem = new QListWidgetItem(account.username());
	pItem->setData(Qt::UserRole , account.toJson());
	ui->lstAccounts->addItem(pItem);
}

void Widget_Accounts::saveAccounts() {
	QList<Account> accounts;
	for(int i = 0 ; i < ui->lstAccounts->count() ; i++) {
		QListWidgetItem * pItem = ui->lstAccounts->item(i);
		QJsonObject oAccount = pItem->data(Qt::UserRole).toJsonObject();
		Account account = Account::fromJson(oAccount);
		accounts << account;
	}
	Common::saveAccounts(accounts);
}

void Widget_Accounts::deleteSelectedAccount() {
	QListWidgetItem * pItem = ui->lstAccounts->currentItem();
	if(!pItem) return;
	delete pItem;
}

void Widget_Accounts::onActionSwitchToPlugins() {
	MainWindow::switchWidget(MainWindow::eWidget_Plugins);
}

void Widget_Accounts::onActionAddAccount() {
	qDebug() << "Action Add Account wurde gelicked!";
	QString sUsername = ui->txtUsername->text();
	QString sPassword = ui->txtPassword->text();
	Account account;
	account.setUsername(sUsername);
	account.setPassword(sPassword);
	addAccountToList(account);
	saveAccounts();
}

void Widget_Accounts::onActionDeleteAccount() {
	deleteSelectedAccount();
	saveAccounts();
}
