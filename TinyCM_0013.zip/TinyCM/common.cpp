#include "common.h"
#include <QCoreApplication>

Account Common::m_account;
QString Common::m_sFilenameAccounts;
WebsocketClient * Common::m_pWebsocketClient;
QString Common::m_sTinyServUrl;

Common::Common() {
	m_sFilenameAccounts = qApp->applicationDirPath() + "/accounts.json";
	m_pWebsocketClient = nullptr;
	m_sTinyServUrl = "ws://localhost:5523";
}

void Common::setAccount(const Account & acc) {
	m_account = acc;
}

Account & Common::account() {
	return m_account;
}

QList<Account> Common::loadAccounts() {
	return Account::fromJsonFile(m_sFilenameAccounts);
}

void Common::saveAccounts(const QList<Account> & accounts) {
	Account::toJsonFile(accounts , m_sFilenameAccounts);
}

WebsocketClient * Common::wsClient() {
	return m_pWebsocketClient;
}

void Common::initwsClient() {
	m_pWebsocketClient = new WebsocketClient();
}

QString Common::tinyServUrl() {
	return m_sTinyServUrl;
}
