#ifndef COMMON_H
#define COMMON_H

#include "Account.h"
#include "WebsocketClient.h"

/**
 * @brief In der Klasse Common legen wir Daten ab, die wir ganz allgemein global von allen Stellen des Programms
 * aus, im Zugriff haben möchten.
 *
 * @date 2021-03-26
 * @author Achim Rautenberg
 */

class Common {
private:
	/**
	 * @brief Der Account mit dem wir uns eingeloggt haben
	 * @date 2021-03-26
	 * @author Achim Rautenberg
	 */
	static Account m_account;

	/*
	 * Der Dateiname, wo die Accounts liegen
	 * TODO soll durch Server ersetzt werden
	 */
	static QString m_sFilenameAccounts;

	/*
	 * Der statische Websocket-Client zur Verbindung mit dem TinyServ
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	static WebsocketClient * m_pWebsocketClient;

	/*
	 * Die Url wo der Server steht
	 * z.B. ws://localhost:5523
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	static QString m_sTinyServUrl;

public:
	Common();

	/**
	 * @brief legt den Account fest, mit dem wir uns eingeloggt haben
	 * @param Der eingeloggte Account
	 * @date 2021-03-26
	 * @author Achim Rautenberg
	 */
	static void setAccount(const Account & acc);

	/**
	 * @brief Gibt den eingeloggten Account zurück.
	 * @return der eingeloggte Account
	 * @date 2021-03-26
	 * @author Achim Rautenberg
	 */
	static Account & account();

	/**
	  Läd die Liste von Accounts von der Festplatte, die sich am Tiny-CM anmelden dürfen
	  @date 2021-04-11
	  @author Achim Rautenberg
	*/
	static QList<Account> loadAccounts();

	/**
	 * Speichert die Liste von Accounts auf Festplatte, die sich am Tiny-CM anmelden dürfen
	 * @date 2021-04-11
	 * @author Achim Rautenberg
	 */
	static void saveAccounts(const QList<Account> & accounts);

	static WebsocketClient * wsClient();
	static void initwsClient();
	static QString tinyServUrl();
};



#endif // COMMON_H
