#pragma once

/**
  Diese Klasse ein Objekt mit allen Funktionen bereit um sich mit dem Tiny-Serv zu verbinden und
  mit diesem Daten auszutauschen.
  @date 2021-04-14
  @author Achim Rautenberg
  */

#include <QObject>
#include <QWebSocket>
#include <QJsonObject>

class WebsocketClient : public QObject
{
	Q_OBJECT

private:
	/**
	 * @brief m_pClient Der eigentlich Client für die Kommunikation
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	QWebSocket * m_pClient;

public:
	/**
	 * @brief Der Konstruktor
	 * @param parent - nicht genutzt
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	explicit WebsocketClient(QObject *parent = nullptr);

	/**
	  Der Destruktor
	  @date 2021-04-14
	  @author Achim Rautenberg
	  */
	~WebsocketClient();

	/**
	 * @brief Mit dieser Funktion kann der Client eine Verbindung zum Server aufbauen.
	 * Dazu braucht er eine URL als String übergeben, wohin er sich verbinden soll.
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	void connectToServer(const QString & sUrl);

	/**
	 * Sendet eine Nachricht an den Server (sofern verbunden).
	 * @param o:QJsonObject ein JsonObject, welches die Daten enthält, die wir dem Server senden wollen.
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	void sendMessage(const QJsonObject & o);

private slots:
	/**
	 * Dieser Slot wird aufgerufen, wenn der Client mit dem Server verbunden ist.
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	void onConnected();

	/**
	 * Dieser Slot wird aufgerufen, wenn der Server uns eine Nachricht geschickt hat.
	 * @param message Die vom Server übergebene Nachricht. Es wird erwartet, dass diese UTF8 codiert ist.
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	void onTextMessageReceived(const QString & message);

	/**
	 * @brief Dieser Slot wird aufgerufen, wenn der Server uns eine Nachricht geschickt hat.
	 * @param message Die vom Server übergebene Nachricht als UTF8 codiertes QByteArray
	 * @date 2021-04-14
	 * @author Achim Rautenberg
	 */
	void onBinaryMessageReceived(const QByteArray & message);
};

