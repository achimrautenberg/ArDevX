#include "PluginManager.h"
#include <QJsonObject>
#include <QJsonDocument>
#include <QDir>
#include <QCoreApplication>

/**
 * Mit dieser Klasse stellen wir uns Funktionen bereit um zur Laufzeit des Servers
 * Bibliotheken laden zu können, die wir dann als Plugins in unserem Server verwenden können.
 *
 * @date 2021-04-14
 * @author Achim Rautenberg
 */

PluginManager::PluginManager() {
}

PluginManager::~PluginManager() {
	while (m_libs.count()) {
		QLibrary * pLib = m_libs.takeFirst();
		pLib->deleteLater();
	}
}

void PluginManager::initLibs() {
	QString sBasePath = qApp->applicationDirPath() + "/Plugins";
	QDir dir(sBasePath);
	QList<QString> entries = dir.entryList(QStringList() << "*.dll" , QDir::Files);
	for(int i = 0 ; i < entries.count() ; i++) {
		QString sFilename = sBasePath + "/" + entries[i];
		loadlib(sFilename);
	}
}

void PluginManager::loadlib(const QString & sFilename){
	QLibrary * pLib = new QLibrary(sFilename);
	bool bLoaded = pLib->load();
	DllMsg fptr = (DllMsg)pLib->resolve("msgToLib");
	if(bLoaded && fptr) {
		m_libs << pLib;
	}else {
		delete pLib;
	}
}

int PluginManager::sendToDll(QJsonObject & o) {
	QJsonDocument doc;
	doc.setObject(o);
	QString sTmp = doc.toJson();
	std::string s = sTmp.toStdString();

	for(int i = 0 ; i < m_libs.count() ; i++) {
		QLibrary * pLib = m_libs[i];
		DllMsg fptr = (DllMsg)pLib->resolve("msgToLib");
		if(fptr) {
			int iReturnValue = fptr(s);
			if(iReturnValue > 0) {
				sTmp = QString::fromStdString(s);
				doc = QJsonDocument::fromJson(sTmp.toUtf8());
				o = doc.object();
				return 1;
			}
		}
	}
	return 0;
}
