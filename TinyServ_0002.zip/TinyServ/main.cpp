#include <QCoreApplication>
#include "WebsocketServer.h"

int main(int argc, char *argv[])
{
	QCoreApplication a(argc, argv);

	WebsocketServer * pServer = new WebsocketServer();
	pServer->startServer(5523);

	return a.exec();
}
