#include "Account.h"
#include <QJsonDocument>
#include <QFile>

Account::Account() {
	m_sUsername = "";
	m_sPassword = "";
}

void Account::setUsername(const QString & sUsername) {
	m_sUsername = sUsername;
}

const QString & Account::username() const {
	return m_sUsername;
}

void Account::setPassword(const QString & sPassword) {
	m_sPassword = sPassword;
}

const QString & Account::password() const {
	return m_sPassword;
}

QJsonObject Account::toJson() const {
	QJsonObject o;
	o.insert("username" , username());
	o.insert("password" , password());
	return o;
}

bool Account::saveAs(const QString & filename) {
	QJsonObject o = toJson();
	QJsonDocument doc;
	doc.setObject(o);
	QByteArray ba = doc.toJson();
	QFile f(filename);
	if(!f.open(QIODevice::WriteOnly)) return false;
	f.write(ba);
	f.close();
	return true;
}
