#include "MainWindow.h"
#include <QApplication>
#include <QTranslator>
#include <QLocale>

QTranslator translator;

void installTranslator() {
	QString sLocale = QLocale::system().name();
	QList<QString> listLocale = sLocale.split("_");
	if(listLocale.count() < 2) return;
	QString sLg = listLocale[0].toLower();
	bool bLoaded = translator.load(":/TinyCM_" + sLg);
	if(bLoaded) {
		qApp->installTranslator(&translator);
	}
}

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	installTranslator();

	MainWindow w;
	w.show();
	int iReturnValue = a.exec();
	return iReturnValue;
}
