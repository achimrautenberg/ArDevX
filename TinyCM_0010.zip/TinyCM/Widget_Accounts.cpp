#include "Widget_Accounts.h"
#include "ui_Widget_Accounts.h"
#include "MainWindow.h"
#include <QMenu>
#include <QDebug>

Widget_Accounts::Widget_Accounts(QWidget *parent) : QWidget(parent) {
	ui = new Ui::Widget_Accounts();
	ui->setupUi(this);
	initMenuButton();
}

Widget_Accounts::~Widget_Accounts() {
	delete ui;
}

void Widget_Accounts::initMenuButton() {
	QMenu * pMenu = new QMenu();
	ui->btnMenu->setMenu(pMenu);

	QAction * pActionSwitchToPlugins = pMenu->addAction(tr("--> Plugins"));
	connect(pActionSwitchToPlugins , SIGNAL(triggered()) , this , SLOT(onActionSwitchToPlugins()));

	QAction * pActionAddAccount = pMenu->addAction(tr("Add Account"));
	connect(pActionAddAccount , SIGNAL(triggered()) , this , SLOT(onActionAddAccount()));

	QAction * pActionDeleteAccount = pMenu->addAction(tr("Delete Account"));
	connect(pActionDeleteAccount , SIGNAL(triggered()) , this , SLOT(onActionDeleteAccount()));
}

void Widget_Accounts::onActionSwitchToPlugins() {
	MainWindow::switchWidget(MainWindow::eWidget_Plugins);
}

void Widget_Accounts::onActionAddAccount() {
	qDebug() << "Action Add Account wurde gelicked!";
}

void Widget_Accounts::onActionDeleteAccount() {
	qDebug() << "Action Delete Account wurde gelicked!";
}
