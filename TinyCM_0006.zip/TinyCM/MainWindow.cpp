#include "MainWindow.h"
#include "ui_MainWindow.h"
#include "Dlg_Login.h"
#include <QApplication>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
	m_pUi = new Ui::MainWindow();
	m_pUi->setupUi(this);
	m_bLoggedIn = false;
}

MainWindow::~MainWindow()
{
	delete m_pUi;
}

void MainWindow::showEvent(QShowEvent *event) {
	QMainWindow::showEvent(event);
	QMetaObject::invokeMethod(this , "onShown" , Qt::ConnectionType::QueuedConnection);
}

void MainWindow::onShown() {
	if(m_bLoggedIn == false) {
		Dlg_Login dlgLogin(this);
		int iRet = dlgLogin.exec();
		if(iRet == QDialog::Accepted){
			Common::setAccount(dlgLogin.account());
			/*
			QString sFilename = qApp->applicationDirPath() + "/account.json";
			if(!m_account.saveAs(sFilename)){
				QMessageBox::critical(this , "Error" , "Datei konnte nicht gepeichert werden!");
				return;
			}
			m_account.setUsername("dfbkmdgbnkm");
			m_account.setPassword("351561351");
			m_account.load(sFilename);
			*/
			m_bLoggedIn = true;
		}
	}
}
