#ifndef TEST_H
#define TEST_H

int sum_test(int n , int m);

#endif // TEST_H
