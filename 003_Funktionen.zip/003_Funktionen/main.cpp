#include "main.h"
#include "test.h"

int main() {
	int c = sum(3 , 4);
	int d = sum(6 ,1);

	int e = sum_test(10 , 15);
	return 0;
}

int diff(int a, int b) {
	return a - b;
}

int sum(int a , int b) {
	int ergebnis = a + b;
	ergebnis *= 4;
	ergebnis++;
	return ergebnis;
}
