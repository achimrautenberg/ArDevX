#include "main.h"

int sum_test(int n , int m) {
	return sum(n , m);
}

int mul(int a , int b){
	return a * b;
}
