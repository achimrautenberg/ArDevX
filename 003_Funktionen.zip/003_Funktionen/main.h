#ifndef MAIN_H
#define MAIN_H

/*
Diese Funktion summiert 2 Zahlen, multipliziert sie und erhöht das Ergbnis um 1.
@date 2021-03-15
@author Achim Rautenberg
*/
int sum(int a, int b);
int diff(int a, int b);

#endif // MAIN_H
