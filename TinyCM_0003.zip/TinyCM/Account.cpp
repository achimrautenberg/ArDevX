#include "Account.h"

Account::Account() {
	m_sUsername = "";
	m_sPassword = "";
}

void Account::setUsername(const QString & sUsername) {
	m_sUsername = sUsername;
}

const QString & Account::username() const {
	return m_sUsername;
}

void Account::setPassword(const QString & sPassword) {
	m_sPassword = sPassword;
}

const QString & Account::password() const {
	return m_sPassword;
}
