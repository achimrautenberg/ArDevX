#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <QString>

/**
 * Die Objektklasse Account.
 * Ein Account ist ein Mitarbeiter der Firma, der sich am Tiny CM einloggen darf.
 *
 * @date 2021-03-23
 * @author Achim Rautenberg
 */

class Account {

private:
	/**
	 * @brief Der Benutzername
	 *
	 * @date 2021-03-23
	 * @author Achim Rautenberg
	 */
	QString m_sUsername;

	/**
	 * @brief Das Passwort mit der Account abgesichert ist.
	 * Der Account ist zur Zeit noch Klartext.
	 * TODO: Account "verschlüsseln"
	 *
	 * @date 2021-03-23
	 * @author Achim Rautenberg
	 */
	QString m_sPassword;

public:
	/**
	 * Standardkonstruktor
	 *
	 * @date 2021-03-23
	 * @author Achim Rautenberg
	 */
	Account();

	/**
	 * Legt den Benutzernamen fest
	 * @param sUsername: Der Benutzername, den der Account annehmen soll.
	 *
	 * @date 2021-03-23
	 * @author Achim Rautenberg
	 */
	void setUsername(const QString & sUsername);

	/**
	 * Der Benutzername des Accounts
	 * @return der Benutzername
	 */
	const QString & username() const;

	/**
	 * Legt das Passwort für den Benutzernamen fest.
	 * @param das Passwort
	 *
	 * @date 2021-03-23
	 * @author Achim Rautenberg
	 */
	void setPassword(const QString & sPassword);

	/**
	 * Gibt das Passwort für den Account zurück
	 * @return das Passwort (in Klartext)
	 *
	 * @date 2021-03-23
	 * @author Achim Rautenberg
	 */
	const QString & password() const;
};

#endif // ACCOUNT_H
