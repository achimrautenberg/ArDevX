#include "PluginManager.h"
#include <QJsonObject>
#include <QJsonDocument>
#include <QDir>
#include <QCoreApplication>



PluginManager::PluginManager() {
}

PluginManager::~PluginManager() {
	cleanUpLibs();
	while (m_libs.count()) {
		QLibrary * pLib = m_libs.takeFirst();
		pLib->deleteLater();
	}
}

void PluginManager::initLibs() {
	QString sBasePath = qApp->applicationDirPath() + "/Plugins";
	QDir dir(sBasePath);
	QList<QString> entries = dir.entryList(QStringList() << "*.dll" , QDir::Files);
	for(int i = 0 ; i < entries.count() ; i++) {
		QString sFilename = sBasePath + "/" + entries[i];
		loadlib(sFilename);
	}

	QJsonObject o;
	o.insert("cmd" , "initlib");
	QJsonDocument doc;
	doc.setObject(o);
	QString sTmp = doc.toJson();
	std::string sMsg = sTmp.toStdString();

	for(int i = 0 ; i < m_libs.count() ; i++) {
		QLibrary * pLib = m_libs[i];
		DllMsg fptr = (DllMsg)pLib->resolve("msgToLib");
		fptr(sMsg);
	}
}

void PluginManager::cleanUpLibs() {
	QJsonObject o;
	o.insert("cmd" , "cleanuplib");
	QJsonDocument doc;
	doc.setObject(o);
	QString sTmp = doc.toJson();
	std::string sMsg = sTmp.toStdString();
	for(int i = 0 ; i < m_libs.count() ; i++) {
		QLibrary * pLib = m_libs[i];
		DllMsg fptr = (DllMsg)pLib->resolve("msgToLib");
		fptr(sMsg);
	}
}

void PluginManager::loadlib(const QString & sFilename){
	QLibrary * pLib = new QLibrary(sFilename);
	bool bLoaded = pLib->load();
	DllMsg fptr = (DllMsg)pLib->resolve("msgToLib");
	if(bLoaded && fptr) {
		m_libs << pLib;
	}else {
		delete pLib;
	}
}

int PluginManager::sendToDll(QJsonObject & o) {
	QJsonDocument doc;
	doc.setObject(o);
	QString sTmp = doc.toJson();
	std::string s = sTmp.toStdString();

	for(int i = 0 ; i < m_libs.count() ; i++) {
		QLibrary * pLib = m_libs[i];
		DllMsg fptr = (DllMsg)pLib->resolve("msgToLib");
		if(fptr) {
			int iReturnValue = fptr(s);
			if(iReturnValue > 0) {
				sTmp = QString::fromStdString(s);
				doc = QJsonDocument::fromJson(sTmp.toUtf8());
				o = doc.object();
				return 1;
			}
		}
	}
	return 0;
}
