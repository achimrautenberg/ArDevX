#include "WebsocketServer.h"
#include <QDebug>
#include "PluginManager.h"

WebsocketServer::WebsocketServer() {
	QWebSocketServer::SslMode mode = QWebSocketServer::NonSecureMode;
	m_pServer = new QWebSocketServer("TinyServ" , mode);
	connect(m_pServer , SIGNAL(newConnection()) , this , SLOT(onNewConnection()));

	m_pPluginManager = new PluginManager();
	m_pPluginManager->initLibs();
}

WebsocketServer::~WebsocketServer() {
	delete m_pPluginManager;
	m_pServer->deleteLater();
}

void WebsocketServer::startServer(const int & iPort) {
	bool bListening = m_pServer->listen(QHostAddress::AnyIPv4 , iPort);
	if(!bListening) {
		qDebug() << "Error! cannot listen on port" << iPort << "!!!";
		exit(1);
	}
	qDebug() << "Server is listening on port" << iPort;
}

void WebsocketServer::onNewConnection() {
	qDebug() << "New connection";
	QWebSocket * pClient = m_pServer->nextPendingConnection();
	connect(pClient , SIGNAL(textMessageReceived(const QString &)) , this , SLOT(onTextMessageReceived(const QString &)));
	connect(pClient , SIGNAL(binaryMessageReceived(const QByteArray &)) , this , SLOT(onBinaryMessageReceived(const QByteArray &)));
}

void WebsocketServer::onBinaryMessageReceived(const QByteArray & message) {
	qDebug() << message;
	QWebSocket * pClient = dynamic_cast<QWebSocket*>(sender());
	pClient->sendBinaryMessage("200 OK - I got your message");
}

void WebsocketServer::onTextMessageReceived(const QString &message) {
	onBinaryMessageReceived(message.toUtf8());
}
