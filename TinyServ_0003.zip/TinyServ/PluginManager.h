#pragma once
#include <QLibrary>

/**
 * Mit dieser Klasse stellen wir uns Funktionen bereit um zur Laufzeit des Servers
 * Bibliotheken laden zu können, die wir dann als Plugins in unserem Server verwenden können.
 *
 * @date 2021-04-14
 * @author Achim Rautenberg
 */

/**
 * Typendefinition für den Funktionpointer über den wir mit der jeweiligen
 * Bibliothek kommunizieren
 * @date 2021-04-14
 * @author Achim Rautenberg
 */
typedef int (*DllMsg)(std::string &);

class PluginManager
{
private:
	/**
	 * Liste mit geladenen Bibliotheken
	 * @date 2021-04-24
	 * @author Achim Rautenberg
	 */
	QList<QLibrary*> m_libs;

public:
	/**
	 * Konstruktor
	 * @date 2021-04-24
	 * @author Achim Rautenberg
	 */
	PluginManager();

	/**
	  Destruktor
	  @dater 2021-04-24
	  @author Achim Rautenberg
	  */
	~PluginManager();

	/**
	 * Geht alle geladenen durch und schickt jeder Bibliothek
	 * den Befehl sich zu initialisieren.
	 * @date 2021-04-25
	 * @author Achim Rautenberg
	 */
	void initLibs();

	/**
	 * Geht alle geladenen Bibliotheken durch und schickt jeder
	 * Bibliothek die Nachricht, sich aufzuräumen (weil sie gleich
	 * entladen wird)
	 * @date 2021-04-25
	 * @author Achim Rautenberg
	 */
	void cleanUpLibs();

	/**
	 * Als sFilename wird der Name inklusive des Pfades (absolut oder relativ) angegeben.
	 * @param sFilename
	 * @return
	 */
	void loadlib(const QString & sFilename);

	/**
	 * Schickt eine Nachricht an jede geladene Bibliothek.
	 * Sobald eine Bibliothek die Nachricht verarbeiten konnte
	 * kann diese das JsonObject im Argument überschreiben.
	 * Als Return Wert wird das 1 zurückgegeben.
	 * Sollte keine DLL sich um die Nachricht gekümmert haben,
	 * wird eine 0 zurückgegeben und das Argument nicht verändert.
	 * @date 2021-04-24
	 * @author Achim Rautenberg
	 */
	int sendToDll(QJsonObject & o);
};

